---
title: Data grid
menu: help.docs.components.datagrid
description: Use the data grid component to display detailed information about your product. The data is displayed as a column of items consisting of a title and content.
---

{% capture code %}
{% include parts/datagrid.html %}
{% endcapture %}
{% include example.html code=code wrapper="demo-dividers" %}